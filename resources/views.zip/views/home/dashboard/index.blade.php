@extends('layouts.navigation1')
@section('title','Panel de control ')
@section('content')
      <!-- Mobile sidebar -->

    
          <div class="container px-6 mx-auto grid">
            <h2
              class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200"
            >
            Panel de control 
            </h2>
          </div>
       
    @endsection 
 
